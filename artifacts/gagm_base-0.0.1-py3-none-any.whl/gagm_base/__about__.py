# SPDX-FileCopyrightText: 2024-present Botond, Kocsis <kocsis@inf.u-szeged.hu>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
